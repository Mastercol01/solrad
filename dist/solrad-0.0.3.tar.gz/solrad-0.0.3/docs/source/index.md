% solrad documentation master file, created by
% sphinx-quickstart on Thu Dec 28 09:46:39 2023.
% You can adapt this file completely to your liking, but it should at least
% contain the root `toctree` directive.

# Solrad
```{include} ../../README.md
:relative-images:
```

```{toctree}
:caption: 'Contents:'
:maxdepth: 2

notebooks/tutorial1_satellite_databases
notebooks/tutorial2_site
notebooks/tutorial3_sky
modules
```

